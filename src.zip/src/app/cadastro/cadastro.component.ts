import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { Pessoa } from '../pessoa';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {

  pessoa: Pessoa = new Pessoa(0, '', '', '', 0);
  message:any;

  constructor(private service:ServiceService, private router:Router) { }

  ngOnInit(): void {
  }

  public cadastrar(){
    let response = this.service.cadastro(this.pessoa);
    response.subscribe((data)=>this.message=data);
    this.router.navigate(['deletar']);
  }

}
