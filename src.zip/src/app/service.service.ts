import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Pessoa } from './pessoa';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClient) { }

  public cadastro(pessoa){
    return this.http.post("http://127.0.0.1:8080/cadastro", pessoa, {responseType:'text' as 'json'});
  }

  public getAllPessoa(){
    return this.http.get("http://127.0.0.1:8080/getAllPessoa");
  }
}
