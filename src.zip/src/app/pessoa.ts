export class Pessoa{
    constructor(
        public id:Number,
        public nome:String,
        public email:String,
        public cpf:String,
        public nascimento:Number
    ){}
}