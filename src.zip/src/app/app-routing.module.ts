import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CadastroComponent } from './cadastro/cadastro.component';
import { EditarComponent } from './editar/editar.component';
import { DeletarComponent } from './deletar/deletar.component';


const routes: Routes = [
{path:"",redirectTo:"cadastrar", pathMatch:"full"},
{path:"cadastrar", component:CadastroComponent},
{path:"editar", component:EditarComponent},
{path:"deletar", component:DeletarComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
