import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deletar',
  templateUrl: './deletar.component.html',
  styleUrls: ['./deletar.component.css']
})
export class DeletarComponent implements OnInit {

  //TIPO any: ACEITA QUALQUE INFORMACAO(STRING, INT, DOUBLE, BOOLEAN)
  pessoas: any;

  constructor(private service:ServiceService ,private router:Router) { }

  ngOnInit(): void {
    let respose = this.service.getAllPessoa();
    respose.subscribe((data) => this.pessoas=data);
  }

}
