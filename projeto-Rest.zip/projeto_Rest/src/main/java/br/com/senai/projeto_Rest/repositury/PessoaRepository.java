package br.com.senai.projeto_Rest.repositury;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.senai.projeto_Rest.model.Pessoa;

// RESPONSAVEL PELA PARTE DA DAO (INSERT, UPDATE, DELETE, SELECT)
public interface PessoaRepository extends JpaRepository<Pessoa, Integer> {

	List<Pessoa> findByEmail(String email); // POSSIBILIDADE DE FAZER BUSCA COM EMAIL

}
