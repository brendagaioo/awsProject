package br.com.senai.projeto_Rest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data // PERSISTENCIA DOS DADOS
@ToString // CRIA O TO STRING
@AllArgsConstructor // ANOTACOES PARA GERAR CONTRUTORES DE FORMA ANONIMA
@NoArgsConstructor // ANOTACOES PARA GERAR CONTRUTORES DE FORMA ANONIMA
@Table(name = "PESSOAS")
public class Pessoa {

	@Id
	@GeneratedValue
	private int id;
	private String nome;
	private String cpf;
	private String email;
	private int nascimento;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getNascimento() {
		return nascimento;
	}

	public void setNascimento(int nascimento) {
		this.nascimento = nascimento;
	}

}
