package br.com.senai.projeto_Rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
